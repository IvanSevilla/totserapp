package com.totserapp.model;

public class Admin extends Usuari{

    public Admin(String nom, String nick, String password, String adreca, String dni) {
        super(nom, nick, password, adreca, dni);
    }
}
