package com.totserapp.model;

public class Actor extends Artista{

    public Actor(String nom, String nacionalitat) {
        super(nom, nacionalitat);
    }
}
