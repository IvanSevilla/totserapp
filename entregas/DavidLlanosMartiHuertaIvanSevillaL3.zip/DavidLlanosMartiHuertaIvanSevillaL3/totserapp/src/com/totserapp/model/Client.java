package com.totserapp.model;

public class Client extends Usuari{

    public Client(String nom, String nick, String password, String adreca, String dni) {
        super(nom, nick, password, adreca, dni);
    }
}
