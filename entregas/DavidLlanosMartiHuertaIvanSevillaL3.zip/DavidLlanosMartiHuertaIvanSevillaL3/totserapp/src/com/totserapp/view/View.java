package com.totserapp.view;

public class View extends javax.swing.JFrame{
    
    /**
     * Mostra la finestra
     * 
     */
    public void mostrar(){
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
