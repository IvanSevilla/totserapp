package com.totserapp.model;

public class Director extends Artista{

    public Director(String nom, String nacionalitat) {
        super(nom, nacionalitat);
    }
}
