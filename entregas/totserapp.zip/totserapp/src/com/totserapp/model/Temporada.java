package com.totserapp.model;

public class Temporada {
    
}
